﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LopushokApp.ModelEF;

namespace LopushokApp.Utils
{
    class DbContext
    {
        public static Model1 db = new Model1();
    }
}
