﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;
using SchweikaApp.Views.PartialView;

namespace SchweikaApp.Views
{
    public partial class ProductPage : Form
    {
        #region Показ данных
        public Form prevPage = LoginPage.ActiveForm;
        public static List<Product> products = new List<Product>();
        public static List<ProductCard> selectedProductCard = new List<ProductCard>();
        public ProductPage()
        {
            InitializeComponent();
            products = DbContext.db.Product.ToList();
        }
        private void GenerateProductCards(List<Product> product)
        {
            foreach (var prCard in product)
            {
                ProductCard card = new ProductCard();
                card.GenerateProductCard(prCard);
                flowLayoutPanel1.Controls.Add(card);
                //card.DoubleClick += new System.EventHandler(this.AgentCard_DoubleClick);
            }
        }
        #endregion
        #region Поиск, фильтрация, сортировка и убывание
        private void ProductPage_Load(object sender, EventArgs e)
        {
            SortComboBox.SelectedIndex = 0;
        }
        private void SortListView()
        {
            var listUpdate = DbContext.db.Product.ToList();
            #region Поиск
            if (SearchTextBox.Text != "Введите для поиска" && !string.IsNullOrWhiteSpace(SearchTextBox.Text))
            {
                listUpdate = listUpdate.Where(p => p.ProductName.ToLower().Contains(SearchTextBox.Text.ToLower())).ToList();
            }
            #endregion            
            #region Фильтрация
            //if (FilterComboBox.Text == "0-9,99%")
                    //listUpdate = listUpdate.Where(discount => discount.ProductDiscountAmount >= 0 && discount.ProductDiscountAmount <= 9,99).ToList();
            #endregion            
            #region Сортировка
            if (SortComboBox.Text == "Скидка")
            {
                if (!DescCheckBox.Checked)
                    listUpdate = listUpdate.OrderBy(a => a.ProductDiscountAmount).ToList();
                else
                    listUpdate = listUpdate.OrderByDescending(a => a.ProductDiscountAmount).ToList();
            }
            else if (SortComboBox.Text == "Без сортировки")
            {
                listUpdate = DbContext.db.Product.ToList();
            }
            #endregion
            flowLayoutPanel1.Controls.Clear();
            GenerateProductCards(listUpdate);
        }
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            SortListView();
        }
        private void SortComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            SortListView();
        }
        private void FilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            SortListView();
        }
        private void DescCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            SortListView();
        }
        #endregion

        #region Кнопки (или объекты со св-вом Click)
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            prevPage.Show();
        }
        //private void AgentCard_DoubleClick(object sender, EventArgs e)
        //{
        //    AgentCard card = sender as AgentCard;
        //    card.BackColor = Color.FromArgb(67, 220, 254);
        //    selectedAgentCard.Add(card);
        //    EditAgentPage editAgent = new EditAgentPage();
        //    DialogResult result = editAgent.ShowDialog();
        //    if (result == DialogResult.OK)
        //    {
        //        SortListView();
        //    }
        //    card.BackColor = Color.White;
        //    SortListView();
        //}
        #endregion
    }
}
