﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;

namespace SchweikaApp.Views.PartialView
{
    public partial class ProductCard : UserControl
    {
        public ProductCard()
        {
            InitializeComponent();
        }
        public void GenerateProductCard(Product product)
        {
            string path = null;
            ProductPicture.ImageLocation = product.ProductImage;
            ProductNameLbl.Text = product.ProductName;
            DescriptionLbl.Text = product.ProductDescription;
            ManufacturerLbl.Text = product.ProductManufacturer.ProductManufacturerName;
            CostLbl.Text = "Цена: " + product.ProductCost;
            DiscountLbl.Text = (Convert.ToString(product.ProductDiscountAmount) + "%");
        }
    }
}
