﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;
using SchweikaApp.Views.PartialView;

namespace SchweikaApp.Views
{
    public partial class ManagerProductPage : Form
    {
        #region Показ данных
        //public Form prevPage = ManagerPage.ActiveForm;
        public static List<Product> products = new List<Product>();
        public static List<ProductCard> selectedProductCard = new List<ProductCard>();
        public ManagerProductPage()
        {
            InitializeComponent();
            products = DbContext.db.Product.ToList();
        }
        private void GenerateProductCards(List<Product> product)
        {
            foreach (var prCard in product)
            {
                ProductCard card = new ProductCard();
                card.GenerateProductCard(prCard);
                flowLayoutPanel1.Controls.Add(card);
                card.DoubleClick += new System.EventHandler(this.ProductCard_DoubleClick);
            }
        }
        #endregion
        #region Поиск, фильтрация, сортировка и убывание
        private void ManagerProductPage_Load(object sender, EventArgs e)
        {
            FilterComboBox.SelectedIndex = 0;
            FilterComboBox.Text = "Без фильтрации";
            SortComboBox.SelectedIndex = 0;
        }
        private void SortListView()
        {
            var listUpdate = DbContext.db.Product.ToList();
            #region Поиск
            if (SearchTextBox.Text != "Введите для поиска")//&& !string.IsNullOrWhiteSpace(SearchTextBox.Text)
            {
                listUpdate = listUpdate.Where(p => p.ProductName.ToLower().Contains(SearchTextBox.Text.ToLower())).ToList();
            }
            #endregion            
            #region Фильтрация
            if (FilterComboBox.SelectedIndex > 0)
            {
                switch (FilterComboBox.Text)
                {
                    case "0-9,99%":
                        listUpdate = listUpdate.Where(d => d.ProductDiscountAmount >= 0 && d.ProductDiscountAmount <= 9.99).ToList();
                        break;
                    case "10-14,99%":
                        listUpdate = listUpdate.Where(d => d.ProductDiscountAmount >= 10 && d.ProductDiscountAmount <= 14.99).ToList();
                        break;
                    case "15% и более":
                        listUpdate = listUpdate.Where(d => d.ProductDiscountAmount >= 15).ToList();
                        break;
                }
            }
            #endregion            
            #region Сортировка
            if (SortComboBox.Text == "Стоимость")
            {
                if (!DescCheckBox.Checked)
                    listUpdate = listUpdate.OrderBy(a => a.ProductCost).ToList();
                else
                    listUpdate = listUpdate.OrderByDescending(a => a.ProductCost).ToList();
            }
            #endregion
            flowLayoutPanel1.Controls.Clear();
            GenerateProductCards(listUpdate);
        }
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void SortComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void FilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void DescCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        #endregion
        #region Кнопки (или объекты со св-вом Click)
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            ManagerPage managerPage = new ManagerPage();
            managerPage.Show();
            this.Close();
        }
        private void ProductCard_DoubleClick(object sender, EventArgs e)
        {
            ProductCard card = sender as ProductCard;
            card.BackColor = Color.FromArgb(153, 0, 153);
            selectedProductCard.Add(card);
            EditProductPage editAgent = new EditProductPage();
            DialogResult result = editAgent.ShowDialog();
            if (result == DialogResult.OK)
            {
                SortListView();
            }
            card.BackColor = Color.White;
            SortListView();
        }
        #endregion   
    }
}
