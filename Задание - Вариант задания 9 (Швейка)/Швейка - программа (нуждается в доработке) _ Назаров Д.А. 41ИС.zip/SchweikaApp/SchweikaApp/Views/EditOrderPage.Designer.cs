﻿
namespace SchweikaApp.Views
{
    partial class EditOrderPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label clientFullNameLabel;
            System.Windows.Forms.Label orderCodeToGetLabel;
            System.Windows.Forms.Label orderCreationDateLabel;
            System.Windows.Forms.Label orderDeliveryDateLabel;
            System.Windows.Forms.Label orderIDLabel;
            System.Windows.Forms.Label orderPickupPointIDLabel;
            System.Windows.Forms.Label orderStatusIDLabel;
            System.Windows.Forms.Label orderPickupPoint1Label;
            System.Windows.Forms.Label iDLabel;
            System.Windows.Forms.Label orderStatusNameLabel;
            System.Windows.Forms.Label iDLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditOrderPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.PageHeadPicture = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.iDTextBox1 = new System.Windows.Forms.TextBox();
            this.orderStatusNameTextBox = new System.Windows.Forms.TextBox();
            this.iDTextBox = new System.Windows.Forms.TextBox();
            this.orderPickupPoint1TextBox = new System.Windows.Forms.TextBox();
            this.clientFullNameTextBox = new System.Windows.Forms.TextBox();
            this.orderCodeToGetTextBox = new System.Windows.Forms.TextBox();
            this.orderCreationDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.orderDeliveryDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.orderIDTextBox = new System.Windows.Forms.TextBox();
            this.orderPickupPointIDTextBox = new System.Windows.Forms.TextBox();
            this.orderStatusIDTextBox = new System.Windows.Forms.TextBox();
            this.orderProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            clientFullNameLabel = new System.Windows.Forms.Label();
            orderCodeToGetLabel = new System.Windows.Forms.Label();
            orderCreationDateLabel = new System.Windows.Forms.Label();
            orderDeliveryDateLabel = new System.Windows.Forms.Label();
            orderIDLabel = new System.Windows.Forms.Label();
            orderPickupPointIDLabel = new System.Windows.Forms.Label();
            orderStatusIDLabel = new System.Windows.Forms.Label();
            orderPickupPoint1Label = new System.Windows.Forms.Label();
            iDLabel = new System.Windows.Forms.Label();
            orderStatusNameLabel = new System.Windows.Forms.Label();
            iDLabel1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PageHeadPicture)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderProductBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // clientFullNameLabel
            // 
            clientFullNameLabel.AutoSize = true;
            clientFullNameLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            clientFullNameLabel.Location = new System.Drawing.Point(228, 41);
            clientFullNameLabel.Name = "clientFullNameLabel";
            clientFullNameLabel.Size = new System.Drawing.Size(166, 28);
            clientFullNameLabel.TabIndex = 0;
            clientFullNameLabel.Text = "Client Full Name:";
            // 
            // orderCodeToGetLabel
            // 
            orderCodeToGetLabel.AutoSize = true;
            orderCodeToGetLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderCodeToGetLabel.Location = new System.Drawing.Point(195, 82);
            orderCodeToGetLabel.Name = "orderCodeToGetLabel";
            orderCodeToGetLabel.Size = new System.Drawing.Size(199, 28);
            orderCodeToGetLabel.TabIndex = 2;
            orderCodeToGetLabel.Text = "Order Code To Get:";
            // 
            // orderCreationDateLabel
            // 
            orderCreationDateLabel.AutoSize = true;
            orderCreationDateLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderCreationDateLabel.Location = new System.Drawing.Point(184, 125);
            orderCreationDateLabel.Name = "orderCreationDateLabel";
            orderCreationDateLabel.Size = new System.Drawing.Size(210, 28);
            orderCreationDateLabel.TabIndex = 4;
            orderCreationDateLabel.Text = "Order Creation Date:";
            // 
            // orderDeliveryDateLabel
            // 
            orderDeliveryDateLabel.AutoSize = true;
            orderDeliveryDateLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderDeliveryDateLabel.Location = new System.Drawing.Point(185, 166);
            orderDeliveryDateLabel.Name = "orderDeliveryDateLabel";
            orderDeliveryDateLabel.Size = new System.Drawing.Size(209, 28);
            orderDeliveryDateLabel.TabIndex = 6;
            orderDeliveryDateLabel.Text = "Order Delivery Date:";
            // 
            // orderIDLabel
            // 
            orderIDLabel.AutoSize = true;
            orderIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderIDLabel.Location = new System.Drawing.Point(286, 205);
            orderIDLabel.Name = "orderIDLabel";
            orderIDLabel.Size = new System.Drawing.Size(108, 28);
            orderIDLabel.TabIndex = 8;
            orderIDLabel.Text = "Order ID:";
            // 
            // orderPickupPointIDLabel
            // 
            orderPickupPointIDLabel.AutoSize = true;
            orderPickupPointIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderPickupPointIDLabel.Location = new System.Drawing.Point(171, 246);
            orderPickupPointIDLabel.Name = "orderPickupPointIDLabel";
            orderPickupPointIDLabel.Size = new System.Drawing.Size(223, 28);
            orderPickupPointIDLabel.TabIndex = 10;
            orderPickupPointIDLabel.Text = "Order Pickup Point ID:";
            // 
            // orderStatusIDLabel
            // 
            orderStatusIDLabel.AutoSize = true;
            orderStatusIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderStatusIDLabel.Location = new System.Drawing.Point(220, 287);
            orderStatusIDLabel.Name = "orderStatusIDLabel";
            orderStatusIDLabel.Size = new System.Drawing.Size(174, 28);
            orderStatusIDLabel.TabIndex = 12;
            orderStatusIDLabel.Text = "Order Status ID:";
            // 
            // orderPickupPoint1Label
            // 
            orderPickupPoint1Label.AutoSize = true;
            orderPickupPoint1Label.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderPickupPoint1Label.Location = new System.Drawing.Point(40, 400);
            orderPickupPoint1Label.Name = "orderPickupPoint1Label";
            orderPickupPoint1Label.Size = new System.Drawing.Size(201, 28);
            orderPickupPoint1Label.TabIndex = 16;
            orderPickupPoint1Label.Text = "Order Pickup Point1:";
            // 
            // iDLabel
            // 
            iDLabel.AutoSize = true;
            iDLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            iDLabel.Location = new System.Drawing.Point(198, 359);
            iDLabel.Name = "iDLabel";
            iDLabel.Size = new System.Drawing.Size(43, 28);
            iDLabel.TabIndex = 14;
            iDLabel.Text = "ID:";
            // 
            // orderStatusNameLabel
            // 
            orderStatusNameLabel.AutoSize = true;
            orderStatusNameLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            orderStatusNameLabel.Location = new System.Drawing.Point(398, 403);
            orderStatusNameLabel.Name = "orderStatusNameLabel";
            orderStatusNameLabel.Size = new System.Drawing.Size(201, 28);
            orderStatusNameLabel.TabIndex = 20;
            orderStatusNameLabel.Text = "Order Status Name:";
            // 
            // iDLabel1
            // 
            iDLabel1.AutoSize = true;
            iDLabel1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            iDLabel1.Location = new System.Drawing.Point(556, 362);
            iDLabel1.Name = "iDLabel1";
            iDLabel1.Size = new System.Drawing.Size(43, 28);
            iDLabel1.TabIndex = 18;
            iDLabel1.Text = "ID:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.CloseBtn);
            this.panel1.Controls.Add(this.PageHeadPicture);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(794, 113);
            this.panel1.TabIndex = 0;
            // 
            // CloseBtn
            // 
            this.CloseBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CloseBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.CloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(0)))), ((int)(((byte)(153)))));
            this.CloseBtn.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseBtn.ForeColor = System.Drawing.Color.White;
            this.CloseBtn.Location = new System.Drawing.Point(737, 9);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(45, 42);
            this.CloseBtn.TabIndex = 34;
            this.CloseBtn.Text = "X";
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // PageHeadPicture
            // 
            this.PageHeadPicture.Image = ((System.Drawing.Image)(resources.GetObject("PageHeadPicture.Image")));
            this.PageHeadPicture.Location = new System.Drawing.Point(12, 12);
            this.PageHeadPicture.Name = "PageHeadPicture";
            this.PageHeadPicture.Size = new System.Drawing.Size(88, 88);
            this.PageHeadPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PageHeadPicture.TabIndex = 27;
            this.PageHeadPicture.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(204)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 681);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(794, 81);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(iDLabel1);
            this.panel3.Controls.Add(this.iDTextBox1);
            this.panel3.Controls.Add(orderStatusNameLabel);
            this.panel3.Controls.Add(this.orderStatusNameTextBox);
            this.panel3.Controls.Add(iDLabel);
            this.panel3.Controls.Add(this.iDTextBox);
            this.panel3.Controls.Add(orderPickupPoint1Label);
            this.panel3.Controls.Add(this.orderPickupPoint1TextBox);
            this.panel3.Controls.Add(clientFullNameLabel);
            this.panel3.Controls.Add(this.clientFullNameTextBox);
            this.panel3.Controls.Add(orderCodeToGetLabel);
            this.panel3.Controls.Add(this.orderCodeToGetTextBox);
            this.panel3.Controls.Add(orderCreationDateLabel);
            this.panel3.Controls.Add(this.orderCreationDateDateTimePicker);
            this.panel3.Controls.Add(orderDeliveryDateLabel);
            this.panel3.Controls.Add(this.orderDeliveryDateDateTimePicker);
            this.panel3.Controls.Add(orderIDLabel);
            this.panel3.Controls.Add(this.orderIDTextBox);
            this.panel3.Controls.Add(orderPickupPointIDLabel);
            this.panel3.Controls.Add(this.orderPickupPointIDTextBox);
            this.panel3.Controls.Add(orderStatusIDLabel);
            this.panel3.Controls.Add(this.orderStatusIDTextBox);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 113);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(794, 568);
            this.panel3.TabIndex = 2;
            // 
            // iDTextBox1
            // 
            this.iDTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderStatus.ID", true));
            this.iDTextBox1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.iDTextBox1.Location = new System.Drawing.Point(623, 359);
            this.iDTextBox1.Name = "iDTextBox1";
            this.iDTextBox1.Size = new System.Drawing.Size(125, 35);
            this.iDTextBox1.TabIndex = 19;
            // 
            // orderStatusNameTextBox
            // 
            this.orderStatusNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderStatus.OrderStatusName", true));
            this.orderStatusNameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderStatusNameTextBox.Location = new System.Drawing.Point(623, 400);
            this.orderStatusNameTextBox.Name = "orderStatusNameTextBox";
            this.orderStatusNameTextBox.Size = new System.Drawing.Size(125, 35);
            this.orderStatusNameTextBox.TabIndex = 21;
            // 
            // iDTextBox
            // 
            this.iDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderPickupPoint.ID", true));
            this.iDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.iDTextBox.Location = new System.Drawing.Point(269, 359);
            this.iDTextBox.Name = "iDTextBox";
            this.iDTextBox.Size = new System.Drawing.Size(125, 35);
            this.iDTextBox.TabIndex = 15;
            // 
            // orderPickupPoint1TextBox
            // 
            this.orderPickupPoint1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderPickupPoint.OrderPickupPoint1", true));
            this.orderPickupPoint1TextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderPickupPoint1TextBox.Location = new System.Drawing.Point(269, 400);
            this.orderPickupPoint1TextBox.Name = "orderPickupPoint1TextBox";
            this.orderPickupPoint1TextBox.Size = new System.Drawing.Size(125, 35);
            this.orderPickupPoint1TextBox.TabIndex = 17;
            // 
            // clientFullNameTextBox
            // 
            this.clientFullNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.ClientFullName", true));
            this.clientFullNameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clientFullNameTextBox.Location = new System.Drawing.Point(412, 38);
            this.clientFullNameTextBox.Name = "clientFullNameTextBox";
            this.clientFullNameTextBox.Size = new System.Drawing.Size(250, 35);
            this.clientFullNameTextBox.TabIndex = 1;
            // 
            // orderCodeToGetTextBox
            // 
            this.orderCodeToGetTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderCodeToGet", true));
            this.orderCodeToGetTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderCodeToGetTextBox.Location = new System.Drawing.Point(412, 79);
            this.orderCodeToGetTextBox.Name = "orderCodeToGetTextBox";
            this.orderCodeToGetTextBox.Size = new System.Drawing.Size(250, 35);
            this.orderCodeToGetTextBox.TabIndex = 3;
            // 
            // orderCreationDateDateTimePicker
            // 
            this.orderCreationDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.orderProductBindingSource, "Order.OrderCreationDate", true));
            this.orderCreationDateDateTimePicker.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderCreationDateDateTimePicker.Location = new System.Drawing.Point(412, 120);
            this.orderCreationDateDateTimePicker.Name = "orderCreationDateDateTimePicker";
            this.orderCreationDateDateTimePicker.Size = new System.Drawing.Size(250, 35);
            this.orderCreationDateDateTimePicker.TabIndex = 5;
            // 
            // orderDeliveryDateDateTimePicker
            // 
            this.orderDeliveryDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.orderProductBindingSource, "Order.OrderDeliveryDate", true));
            this.orderDeliveryDateDateTimePicker.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderDeliveryDateDateTimePicker.Location = new System.Drawing.Point(412, 161);
            this.orderDeliveryDateDateTimePicker.Name = "orderDeliveryDateDateTimePicker";
            this.orderDeliveryDateDateTimePicker.Size = new System.Drawing.Size(250, 35);
            this.orderDeliveryDateDateTimePicker.TabIndex = 7;
            // 
            // orderIDTextBox
            // 
            this.orderIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderID", true));
            this.orderIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderIDTextBox.Location = new System.Drawing.Point(412, 202);
            this.orderIDTextBox.Name = "orderIDTextBox";
            this.orderIDTextBox.Size = new System.Drawing.Size(250, 35);
            this.orderIDTextBox.TabIndex = 9;
            // 
            // orderPickupPointIDTextBox
            // 
            this.orderPickupPointIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderPickupPointID", true));
            this.orderPickupPointIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderPickupPointIDTextBox.Location = new System.Drawing.Point(412, 243);
            this.orderPickupPointIDTextBox.Name = "orderPickupPointIDTextBox";
            this.orderPickupPointIDTextBox.Size = new System.Drawing.Size(250, 35);
            this.orderPickupPointIDTextBox.TabIndex = 11;
            // 
            // orderStatusIDTextBox
            // 
            this.orderStatusIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.orderProductBindingSource, "Order.OrderStatusID", true));
            this.orderStatusIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderStatusIDTextBox.Location = new System.Drawing.Point(412, 284);
            this.orderStatusIDTextBox.Name = "orderStatusIDTextBox";
            this.orderStatusIDTextBox.Size = new System.Drawing.Size(250, 35);
            this.orderStatusIDTextBox.TabIndex = 13;
            // 
            // orderProductBindingSource
            // 
            this.orderProductBindingSource.DataSource = typeof(SchweikaApp.ModelEF.OrderProduct);
            // 
            // EditOrderPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 762);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditOrderPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Работа с данными заказа";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PageHeadPicture)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderProductBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox PageHeadPicture;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.BindingSource orderProductBindingSource;
        private System.Windows.Forms.TextBox clientFullNameTextBox;
        private System.Windows.Forms.TextBox orderCodeToGetTextBox;
        private System.Windows.Forms.DateTimePicker orderCreationDateDateTimePicker;
        private System.Windows.Forms.DateTimePicker orderDeliveryDateDateTimePicker;
        private System.Windows.Forms.TextBox orderIDTextBox;
        private System.Windows.Forms.TextBox orderPickupPointIDTextBox;
        private System.Windows.Forms.TextBox orderStatusIDTextBox;
        private System.Windows.Forms.TextBox iDTextBox1;
        private System.Windows.Forms.TextBox orderStatusNameTextBox;
        private System.Windows.Forms.TextBox iDTextBox;
        private System.Windows.Forms.TextBox orderPickupPoint1TextBox;
        private System.Windows.Forms.Button CloseBtn;
    }
}