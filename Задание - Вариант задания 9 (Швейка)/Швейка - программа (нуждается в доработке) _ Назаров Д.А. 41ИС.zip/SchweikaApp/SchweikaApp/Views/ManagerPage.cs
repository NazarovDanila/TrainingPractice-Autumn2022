﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.Utils;
using SchweikaApp.ModelEF;
using SchweikaApp.Views;

namespace SchweikaApp.Views
{
    public partial class ManagerPage : Form
    {
        //static public Form prevPage = LoginPage.ActiveForm;
        public ManagerPage()
        {
            InitializeComponent();
        }
        #region Кнопки (или объекты со св-вом Click)
        private void ProductBtn_Click(object sender, EventArgs e)
        {
            ManagerProductPage prodPage = new ManagerProductPage();// создаем форму директора                        
            //prevPage = this;// сохраняем в форме куда возвращаться
            prodPage.Show();// показываем форму директора
            this.Hide();// форму подключения скрываем (но не закрываем!)
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            ManagerOrderPage ordPage = new ManagerOrderPage();// создаем форму директора                        
            //prevPage = this;// сохраняем в форме куда возвращаться
            ordPage.Show();// показываем форму директора
            this.Hide();// форму подключения скрываем (но не закрываем!)
        }
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
            //prevPage.Show();
        }
        #endregion
    }
}
