﻿
namespace SchweikaApp.Views
{
    partial class EditProductPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditProductPage));
            System.Windows.Forms.Label productArticleNumberLabel;
            System.Windows.Forms.Label productCategoryIDLabel;
            System.Windows.Forms.Label productCostLabel;
            System.Windows.Forms.Label productDescriptionLabel;
            System.Windows.Forms.Label productDiscountAmountLabel;
            System.Windows.Forms.Label productImageLabel;
            System.Windows.Forms.Label productManufacturerIDLabel;
            System.Windows.Forms.Label productMaxDiscountLabel;
            System.Windows.Forms.Label productNameLabel;
            System.Windows.Forms.Label productQuantityInStockLabel;
            System.Windows.Forms.Label productStatusIDLabel;
            System.Windows.Forms.Label productSupplierIDLabel;
            System.Windows.Forms.Label productUnitOfMeasureIDLabel;
            this.PageHeadPicture = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productArticleNumberTextBox = new System.Windows.Forms.TextBox();
            this.productCategoryIDTextBox = new System.Windows.Forms.TextBox();
            this.productCostTextBox = new System.Windows.Forms.TextBox();
            this.productDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.productDiscountAmountTextBox = new System.Windows.Forms.TextBox();
            this.productImageTextBox = new System.Windows.Forms.TextBox();
            this.productManufacturerIDTextBox = new System.Windows.Forms.TextBox();
            this.productMaxDiscountTextBox = new System.Windows.Forms.TextBox();
            this.productNameTextBox = new System.Windows.Forms.TextBox();
            this.productQuantityInStockTextBox = new System.Windows.Forms.TextBox();
            this.productStatusIDTextBox = new System.Windows.Forms.TextBox();
            this.productSupplierIDTextBox = new System.Windows.Forms.TextBox();
            this.productUnitOfMeasureIDTextBox = new System.Windows.Forms.TextBox();
            this.LogoPicBox = new System.Windows.Forms.PictureBox();
            this.SaveButn = new System.Windows.Forms.Button();
            this.ChangeImageButn = new System.Windows.Forms.Button();
            this.NameLbl = new System.Windows.Forms.Label();
            productArticleNumberLabel = new System.Windows.Forms.Label();
            productCategoryIDLabel = new System.Windows.Forms.Label();
            productCostLabel = new System.Windows.Forms.Label();
            productDescriptionLabel = new System.Windows.Forms.Label();
            productDiscountAmountLabel = new System.Windows.Forms.Label();
            productImageLabel = new System.Windows.Forms.Label();
            productManufacturerIDLabel = new System.Windows.Forms.Label();
            productMaxDiscountLabel = new System.Windows.Forms.Label();
            productNameLabel = new System.Windows.Forms.Label();
            productQuantityInStockLabel = new System.Windows.Forms.Label();
            productStatusIDLabel = new System.Windows.Forms.Label();
            productSupplierIDLabel = new System.Windows.Forms.Label();
            productUnitOfMeasureIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PageHeadPicture)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // PageHeadPicture
            // 
            this.PageHeadPicture.Image = ((System.Drawing.Image)(resources.GetObject("PageHeadPicture.Image")));
            this.PageHeadPicture.Location = new System.Drawing.Point(12, 12);
            this.PageHeadPicture.Name = "PageHeadPicture";
            this.PageHeadPicture.Size = new System.Drawing.Size(88, 88);
            this.PageHeadPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PageHeadPicture.TabIndex = 27;
            this.PageHeadPicture.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.NameLbl);
            this.panel1.Controls.Add(this.CloseBtn);
            this.panel1.Controls.Add(this.PageHeadPicture);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(829, 110);
            this.panel1.TabIndex = 3;
            // 
            // CloseBtn
            // 
            this.CloseBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CloseBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.CloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(0)))), ((int)(((byte)(153)))));
            this.CloseBtn.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseBtn.ForeColor = System.Drawing.Color.White;
            this.CloseBtn.Location = new System.Drawing.Point(754, 8);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(45, 42);
            this.CloseBtn.TabIndex = 34;
            this.CloseBtn.Text = "X";
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(204)))));
            this.panel2.Controls.Add(this.SaveButn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 600);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(829, 85);
            this.panel2.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.ChangeImageButn);
            this.panel3.Controls.Add(this.LogoPicBox);
            this.panel3.Controls.Add(productArticleNumberLabel);
            this.panel3.Controls.Add(this.productArticleNumberTextBox);
            this.panel3.Controls.Add(productCategoryIDLabel);
            this.panel3.Controls.Add(this.productCategoryIDTextBox);
            this.panel3.Controls.Add(productCostLabel);
            this.panel3.Controls.Add(this.productCostTextBox);
            this.panel3.Controls.Add(productDescriptionLabel);
            this.panel3.Controls.Add(this.productDescriptionTextBox);
            this.panel3.Controls.Add(productDiscountAmountLabel);
            this.panel3.Controls.Add(this.productDiscountAmountTextBox);
            this.panel3.Controls.Add(productImageLabel);
            this.panel3.Controls.Add(this.productImageTextBox);
            this.panel3.Controls.Add(productManufacturerIDLabel);
            this.panel3.Controls.Add(this.productManufacturerIDTextBox);
            this.panel3.Controls.Add(productMaxDiscountLabel);
            this.panel3.Controls.Add(this.productMaxDiscountTextBox);
            this.panel3.Controls.Add(productNameLabel);
            this.panel3.Controls.Add(this.productNameTextBox);
            this.panel3.Controls.Add(productQuantityInStockLabel);
            this.panel3.Controls.Add(this.productQuantityInStockTextBox);
            this.panel3.Controls.Add(productStatusIDLabel);
            this.panel3.Controls.Add(this.productStatusIDTextBox);
            this.panel3.Controls.Add(productSupplierIDLabel);
            this.panel3.Controls.Add(this.productSupplierIDTextBox);
            this.panel3.Controls.Add(productUnitOfMeasureIDLabel);
            this.panel3.Controls.Add(this.productUnitOfMeasureIDTextBox);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 110);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(829, 490);
            this.panel3.TabIndex = 5;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataSource = typeof(SchweikaApp.ModelEF.Product);
            // 
            // productArticleNumberLabel
            // 
            productArticleNumberLabel.AutoSize = true;
            productArticleNumberLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productArticleNumberLabel.Location = new System.Drawing.Point(76, 27);
            productArticleNumberLabel.Name = "productArticleNumberLabel";
            productArticleNumberLabel.Size = new System.Drawing.Size(208, 24);
            productArticleNumberLabel.TabIndex = 0;
            productArticleNumberLabel.Text = "Product Article Number:";
            // 
            // productArticleNumberTextBox
            // 
            this.productArticleNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductArticleNumber", true));
            this.productArticleNumberTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productArticleNumberTextBox.Location = new System.Drawing.Point(304, 24);
            this.productArticleNumberTextBox.Name = "productArticleNumberTextBox";
            this.productArticleNumberTextBox.Size = new System.Drawing.Size(156, 31);
            this.productArticleNumberTextBox.TabIndex = 1;
            // 
            // productCategoryIDLabel
            // 
            productCategoryIDLabel.AutoSize = true;
            productCategoryIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productCategoryIDLabel.Location = new System.Drawing.Point(102, 64);
            productCategoryIDLabel.Name = "productCategoryIDLabel";
            productCategoryIDLabel.Size = new System.Drawing.Size(182, 24);
            productCategoryIDLabel.TabIndex = 2;
            productCategoryIDLabel.Text = "Product Category ID:";
            // 
            // productCategoryIDTextBox
            // 
            this.productCategoryIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductCategoryID", true));
            this.productCategoryIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productCategoryIDTextBox.Location = new System.Drawing.Point(304, 61);
            this.productCategoryIDTextBox.Name = "productCategoryIDTextBox";
            this.productCategoryIDTextBox.Size = new System.Drawing.Size(156, 31);
            this.productCategoryIDTextBox.TabIndex = 3;
            // 
            // productCostLabel
            // 
            productCostLabel.AutoSize = true;
            productCostLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productCostLabel.Location = new System.Drawing.Point(165, 101);
            productCostLabel.Name = "productCostLabel";
            productCostLabel.Size = new System.Drawing.Size(119, 24);
            productCostLabel.TabIndex = 4;
            productCostLabel.Text = "Product Cost:";
            // 
            // productCostTextBox
            // 
            this.productCostTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductCost", true));
            this.productCostTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productCostTextBox.Location = new System.Drawing.Point(304, 98);
            this.productCostTextBox.Name = "productCostTextBox";
            this.productCostTextBox.Size = new System.Drawing.Size(156, 31);
            this.productCostTextBox.TabIndex = 5;
            // 
            // productDescriptionLabel
            // 
            productDescriptionLabel.AutoSize = true;
            productDescriptionLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productDescriptionLabel.Location = new System.Drawing.Point(111, 138);
            productDescriptionLabel.Name = "productDescriptionLabel";
            productDescriptionLabel.Size = new System.Drawing.Size(174, 24);
            productDescriptionLabel.TabIndex = 6;
            productDescriptionLabel.Text = "Product Description:";
            // 
            // productDescriptionTextBox
            // 
            this.productDescriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductDescription", true));
            this.productDescriptionTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productDescriptionTextBox.Location = new System.Drawing.Point(305, 135);
            this.productDescriptionTextBox.Name = "productDescriptionTextBox";
            this.productDescriptionTextBox.Size = new System.Drawing.Size(156, 31);
            this.productDescriptionTextBox.TabIndex = 7;
            // 
            // productDiscountAmountLabel
            // 
            productDiscountAmountLabel.AutoSize = true;
            productDiscountAmountLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productDiscountAmountLabel.Location = new System.Drawing.Point(66, 175);
            productDiscountAmountLabel.Name = "productDiscountAmountLabel";
            productDiscountAmountLabel.Size = new System.Drawing.Size(218, 24);
            productDiscountAmountLabel.TabIndex = 8;
            productDiscountAmountLabel.Text = "Product Discount Amount:";
            // 
            // productDiscountAmountTextBox
            // 
            this.productDiscountAmountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductDiscountAmount", true));
            this.productDiscountAmountTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productDiscountAmountTextBox.Location = new System.Drawing.Point(305, 172);
            this.productDiscountAmountTextBox.Name = "productDiscountAmountTextBox";
            this.productDiscountAmountTextBox.Size = new System.Drawing.Size(156, 31);
            this.productDiscountAmountTextBox.TabIndex = 9;
            // 
            // productImageLabel
            // 
            productImageLabel.AutoSize = true;
            productImageLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productImageLabel.Location = new System.Drawing.Point(501, 369);
            productImageLabel.Name = "productImageLabel";
            productImageLabel.Size = new System.Drawing.Size(133, 24);
            productImageLabel.TabIndex = 10;
            productImageLabel.Text = "Product Image:";
            // 
            // productImageTextBox
            // 
            this.productImageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductImage", true));
            this.productImageTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productImageTextBox.Location = new System.Drawing.Point(655, 366);
            this.productImageTextBox.Name = "productImageTextBox";
            this.productImageTextBox.Size = new System.Drawing.Size(156, 31);
            this.productImageTextBox.TabIndex = 11;
            // 
            // productManufacturerIDLabel
            // 
            productManufacturerIDLabel.AutoSize = true;
            productManufacturerIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productManufacturerIDLabel.Location = new System.Drawing.Point(63, 212);
            productManufacturerIDLabel.Name = "productManufacturerIDLabel";
            productManufacturerIDLabel.Size = new System.Drawing.Size(221, 24);
            productManufacturerIDLabel.TabIndex = 12;
            productManufacturerIDLabel.Text = "Product Manufacturer ID:";
            // 
            // productManufacturerIDTextBox
            // 
            this.productManufacturerIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductManufacturerID", true));
            this.productManufacturerIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productManufacturerIDTextBox.Location = new System.Drawing.Point(305, 209);
            this.productManufacturerIDTextBox.Name = "productManufacturerIDTextBox";
            this.productManufacturerIDTextBox.Size = new System.Drawing.Size(156, 31);
            this.productManufacturerIDTextBox.TabIndex = 13;
            // 
            // productMaxDiscountLabel
            // 
            productMaxDiscountLabel.AutoSize = true;
            productMaxDiscountLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productMaxDiscountLabel.Location = new System.Drawing.Point(93, 249);
            productMaxDiscountLabel.Name = "productMaxDiscountLabel";
            productMaxDiscountLabel.Size = new System.Drawing.Size(191, 24);
            productMaxDiscountLabel.TabIndex = 14;
            productMaxDiscountLabel.Text = "Product Max Discount:";
            // 
            // productMaxDiscountTextBox
            // 
            this.productMaxDiscountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductMaxDiscount", true));
            this.productMaxDiscountTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productMaxDiscountTextBox.Location = new System.Drawing.Point(304, 246);
            this.productMaxDiscountTextBox.Name = "productMaxDiscountTextBox";
            this.productMaxDiscountTextBox.Size = new System.Drawing.Size(156, 31);
            this.productMaxDiscountTextBox.TabIndex = 15;
            // 
            // productNameLabel
            // 
            productNameLabel.AutoSize = true;
            productNameLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productNameLabel.Location = new System.Drawing.Point(156, 286);
            productNameLabel.Name = "productNameLabel";
            productNameLabel.Size = new System.Drawing.Size(129, 24);
            productNameLabel.TabIndex = 16;
            productNameLabel.Text = "Product Name:";
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductName", true));
            this.productNameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productNameTextBox.Location = new System.Drawing.Point(304, 283);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.Size = new System.Drawing.Size(156, 31);
            this.productNameTextBox.TabIndex = 17;
            // 
            // productQuantityInStockLabel
            // 
            productQuantityInStockLabel.AutoSize = true;
            productQuantityInStockLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productQuantityInStockLabel.Location = new System.Drawing.Point(53, 323);
            productQuantityInStockLabel.Name = "productQuantityInStockLabel";
            productQuantityInStockLabel.Size = new System.Drawing.Size(231, 24);
            productQuantityInStockLabel.TabIndex = 18;
            productQuantityInStockLabel.Text = "Product Quantity In Stock:";
            // 
            // productQuantityInStockTextBox
            // 
            this.productQuantityInStockTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductQuantityInStock", true));
            this.productQuantityInStockTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productQuantityInStockTextBox.Location = new System.Drawing.Point(304, 320);
            this.productQuantityInStockTextBox.Name = "productQuantityInStockTextBox";
            this.productQuantityInStockTextBox.Size = new System.Drawing.Size(156, 31);
            this.productQuantityInStockTextBox.TabIndex = 19;
            // 
            // productStatusIDLabel
            // 
            productStatusIDLabel.AutoSize = true;
            productStatusIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productStatusIDLabel.Location = new System.Drawing.Point(122, 360);
            productStatusIDLabel.Name = "productStatusIDLabel";
            productStatusIDLabel.Size = new System.Drawing.Size(163, 24);
            productStatusIDLabel.TabIndex = 20;
            productStatusIDLabel.Text = "Product Status ID:";
            // 
            // productStatusIDTextBox
            // 
            this.productStatusIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductStatusID", true));
            this.productStatusIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productStatusIDTextBox.Location = new System.Drawing.Point(305, 357);
            this.productStatusIDTextBox.Name = "productStatusIDTextBox";
            this.productStatusIDTextBox.Size = new System.Drawing.Size(156, 31);
            this.productStatusIDTextBox.TabIndex = 21;
            // 
            // productSupplierIDLabel
            // 
            productSupplierIDLabel.AutoSize = true;
            productSupplierIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productSupplierIDLabel.Location = new System.Drawing.Point(109, 397);
            productSupplierIDLabel.Name = "productSupplierIDLabel";
            productSupplierIDLabel.Size = new System.Drawing.Size(175, 24);
            productSupplierIDLabel.TabIndex = 22;
            productSupplierIDLabel.Text = "Product Supplier ID:";
            // 
            // productSupplierIDTextBox
            // 
            this.productSupplierIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductSupplierID", true));
            this.productSupplierIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productSupplierIDTextBox.Location = new System.Drawing.Point(305, 394);
            this.productSupplierIDTextBox.Name = "productSupplierIDTextBox";
            this.productSupplierIDTextBox.Size = new System.Drawing.Size(156, 31);
            this.productSupplierIDTextBox.TabIndex = 23;
            // 
            // productUnitOfMeasureIDLabel
            // 
            productUnitOfMeasureIDLabel.AutoSize = true;
            productUnitOfMeasureIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            productUnitOfMeasureIDLabel.Location = new System.Drawing.Point(39, 434);
            productUnitOfMeasureIDLabel.Name = "productUnitOfMeasureIDLabel";
            productUnitOfMeasureIDLabel.Size = new System.Drawing.Size(245, 24);
            productUnitOfMeasureIDLabel.TabIndex = 24;
            productUnitOfMeasureIDLabel.Text = "Product Unit Of Measure ID:";
            // 
            // productUnitOfMeasureIDTextBox
            // 
            this.productUnitOfMeasureIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ProductUnitOfMeasureID", true));
            this.productUnitOfMeasureIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.productUnitOfMeasureIDTextBox.Location = new System.Drawing.Point(304, 431);
            this.productUnitOfMeasureIDTextBox.Name = "productUnitOfMeasureIDTextBox";
            this.productUnitOfMeasureIDTextBox.Size = new System.Drawing.Size(156, 31);
            this.productUnitOfMeasureIDTextBox.TabIndex = 25;
            // 
            // LogoPicBox
            // 
            this.LogoPicBox.Location = new System.Drawing.Point(546, 105);
            this.LogoPicBox.Margin = new System.Windows.Forms.Padding(4);
            this.LogoPicBox.Name = "LogoPicBox";
            this.LogoPicBox.Size = new System.Drawing.Size(233, 168);
            this.LogoPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogoPicBox.TabIndex = 26;
            this.LogoPicBox.TabStop = false;
            // 
            // SaveButn
            // 
            this.SaveButn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(0)))), ((int)(((byte)(153)))));
            this.SaveButn.Font = new System.Drawing.Font("Comic Sans MS", 14.25F);
            this.SaveButn.ForeColor = System.Drawing.Color.White;
            this.SaveButn.Location = new System.Drawing.Point(333, 18);
            this.SaveButn.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButn.Name = "SaveButn";
            this.SaveButn.Size = new System.Drawing.Size(163, 49);
            this.SaveButn.TabIndex = 21;
            this.SaveButn.Text = "Сохранить";
            this.SaveButn.UseVisualStyleBackColor = false;
            this.SaveButn.Click += new System.EventHandler(this.SaveButn_Click);
            // 
            // ChangeImageButn
            // 
            this.ChangeImageButn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(0)))), ((int)(((byte)(153)))));
            this.ChangeImageButn.Font = new System.Drawing.Font("Comic Sans MS", 14.25F);
            this.ChangeImageButn.ForeColor = System.Drawing.Color.White;
            this.ChangeImageButn.Location = new System.Drawing.Point(582, 300);
            this.ChangeImageButn.Margin = new System.Windows.Forms.Padding(4);
            this.ChangeImageButn.Name = "ChangeImageButn";
            this.ChangeImageButn.Size = new System.Drawing.Size(163, 49);
            this.ChangeImageButn.TabIndex = 27;
            this.ChangeImageButn.Text = "Выбрать";
            this.ChangeImageButn.UseVisualStyleBackColor = false;
            this.ChangeImageButn.Click += new System.EventHandler(this.ChangeImageButn_Click);
            // 
            // NameLbl
            // 
            this.NameLbl.AutoSize = true;
            this.NameLbl.Font = new System.Drawing.Font("Comic Sans MS", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLbl.Location = new System.Drawing.Point(159, 28);
            this.NameLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameLbl.Name = "NameLbl";
            this.NameLbl.Size = new System.Drawing.Size(520, 60);
            this.NameLbl.TabIndex = 35;
            this.NameLbl.Text = "Редактирование данных";
            // 
            // EditProductPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 685);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditProductPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Работа с данными товара";
            this.Load += new System.EventHandler(this.EditProductPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PageHeadPicture)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPicBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PageHeadPicture;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label NameLbl;
        private System.Windows.Forms.Button SaveButn;
        private System.Windows.Forms.Button ChangeImageButn;
        private System.Windows.Forms.PictureBox LogoPicBox;
        private System.Windows.Forms.TextBox productArticleNumberTextBox;
        private System.Windows.Forms.BindingSource productBindingSource;
        private System.Windows.Forms.TextBox productCategoryIDTextBox;
        private System.Windows.Forms.TextBox productCostTextBox;
        private System.Windows.Forms.TextBox productDescriptionTextBox;
        private System.Windows.Forms.TextBox productDiscountAmountTextBox;
        private System.Windows.Forms.TextBox productImageTextBox;
        private System.Windows.Forms.TextBox productManufacturerIDTextBox;
        private System.Windows.Forms.TextBox productMaxDiscountTextBox;
        private System.Windows.Forms.TextBox productNameTextBox;
        private System.Windows.Forms.TextBox productQuantityInStockTextBox;
        private System.Windows.Forms.TextBox productStatusIDTextBox;
        private System.Windows.Forms.TextBox productSupplierIDTextBox;
        private System.Windows.Forms.TextBox productUnitOfMeasureIDTextBox;
    }
}