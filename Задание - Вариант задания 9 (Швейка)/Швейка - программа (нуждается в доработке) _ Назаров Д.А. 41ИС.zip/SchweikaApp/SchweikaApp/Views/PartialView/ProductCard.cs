﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;

namespace SchweikaApp.Views.PartialView
{
    public partial class ProductCard : UserControl
    {
        public ProductCard()
        {
            InitializeComponent();
        }
        public void GenerateProductCard(Product product)
        {
            ProductPicture.ImageLocation = product.ProductImage;
            ProductNameLbl.Text = product.ProductName;
            DescriptionLbl.Text = product.ProductDescription;
            ManufacturerLbl.Text = product.ProductManufacturer.ProductManufacturerName;
            string cost = Convert.ToString(product.ProductCost);
            cost = cost.Substring(0, cost.Length - 2);
            CostLbl.Text = $"Цена: {cost} руб.";
            DiscountLbl.Text = (Convert.ToString(product.ProductDiscountAmount) + "%");
        }
    }
}
