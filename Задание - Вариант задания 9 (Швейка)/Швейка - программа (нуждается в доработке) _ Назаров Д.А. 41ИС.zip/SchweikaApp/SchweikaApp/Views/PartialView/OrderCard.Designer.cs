﻿
namespace SchweikaApp.Views.PartialView
{
    partial class OrderCard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberStatusLbl = new System.Windows.Forms.Label();
            this.OrderProductLbl = new System.Windows.Forms.Label();
            this.CreateDeliveryDate = new System.Windows.Forms.Label();
            this.PointCodeLbl = new System.Windows.Forms.Label();
            this.ClientFullNameLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NumberStatusLbl
            // 
            this.NumberStatusLbl.AutoSize = true;
            this.NumberStatusLbl.BackColor = System.Drawing.Color.Transparent;
            this.NumberStatusLbl.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumberStatusLbl.ForeColor = System.Drawing.Color.Black;
            this.NumberStatusLbl.Location = new System.Drawing.Point(26, 16);
            this.NumberStatusLbl.Name = "NumberStatusLbl";
            this.NumberStatusLbl.Size = new System.Drawing.Size(362, 35);
            this.NumberStatusLbl.TabIndex = 0;
            this.NumberStatusLbl.Text = "Номер заказа | Статус заказа";
            // 
            // OrderProductLbl
            // 
            this.OrderProductLbl.AutoSize = true;
            this.OrderProductLbl.BackColor = System.Drawing.Color.Transparent;
            this.OrderProductLbl.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OrderProductLbl.ForeColor = System.Drawing.Color.Black;
            this.OrderProductLbl.Location = new System.Drawing.Point(27, 51);
            this.OrderProductLbl.Name = "OrderProductLbl";
            this.OrderProductLbl.Size = new System.Drawing.Size(139, 28);
            this.OrderProductLbl.TabIndex = 1;
            this.OrderProductLbl.Text = "Состав заказа";
            // 
            // CreateDeliveryDate
            // 
            this.CreateDeliveryDate.AutoSize = true;
            this.CreateDeliveryDate.BackColor = System.Drawing.Color.Transparent;
            this.CreateDeliveryDate.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CreateDeliveryDate.ForeColor = System.Drawing.Color.Black;
            this.CreateDeliveryDate.Location = new System.Drawing.Point(27, 79);
            this.CreateDeliveryDate.Name = "CreateDeliveryDate";
            this.CreateDeliveryDate.Size = new System.Drawing.Size(433, 28);
            this.CreateDeliveryDate.TabIndex = 2;
            this.CreateDeliveryDate.Text = "Дата создания заказа | Дата доставки заказа";
            // 
            // PointCodeLbl
            // 
            this.PointCodeLbl.AutoSize = true;
            this.PointCodeLbl.BackColor = System.Drawing.Color.Transparent;
            this.PointCodeLbl.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PointCodeLbl.ForeColor = System.Drawing.Color.Black;
            this.PointCodeLbl.Location = new System.Drawing.Point(27, 107);
            this.PointCodeLbl.Name = "PointCodeLbl";
            this.PointCodeLbl.Size = new System.Drawing.Size(283, 28);
            this.PointCodeLbl.TabIndex = 3;
            this.PointCodeLbl.Text = "Пункт выдачи | Код выдачи";
            // 
            // ClientFullNameLbl
            // 
            this.ClientFullNameLbl.AutoSize = true;
            this.ClientFullNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.ClientFullNameLbl.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientFullNameLbl.ForeColor = System.Drawing.Color.Black;
            this.ClientFullNameLbl.Location = new System.Drawing.Point(27, 135);
            this.ClientFullNameLbl.Name = "ClientFullNameLbl";
            this.ClientFullNameLbl.Size = new System.Drawing.Size(139, 28);
            this.ClientFullNameLbl.TabIndex = 4;
            this.ClientFullNameLbl.Text = "ФИО клиента";
            // 
            // OrderCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ClientFullNameLbl);
            this.Controls.Add(this.PointCodeLbl);
            this.Controls.Add(this.CreateDeliveryDate);
            this.Controls.Add(this.OrderProductLbl);
            this.Controls.Add(this.NumberStatusLbl);
            this.Name = "OrderCard";
            this.Size = new System.Drawing.Size(1154, 186);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NumberStatusLbl;
        private System.Windows.Forms.Label OrderProductLbl;
        private System.Windows.Forms.Label CreateDeliveryDate;
        private System.Windows.Forms.Label PointCodeLbl;
        private System.Windows.Forms.Label ClientFullNameLbl;
    }
}
