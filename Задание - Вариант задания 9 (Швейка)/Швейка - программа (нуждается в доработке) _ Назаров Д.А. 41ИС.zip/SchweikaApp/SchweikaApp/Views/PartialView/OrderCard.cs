﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;

namespace SchweikaApp.Views.PartialView
{
    public partial class OrderCard : UserControl
    {
        public OrderCard()
        {
            InitializeComponent();
        }
        public void GenerateOrderCard(Order order)
        {
            string prod = null;
            int sumDisc = 0, paintingCardOrange = 0;
            NumberStatusLbl.Text = $"№ заказа: {order.OrderID} | Статус заказа: {order.OrderStatus.OrderStatusName}";//Вывод на строку номера и статуса заказа
            foreach(OrderProduct orderProduct in order.OrderProduct)//Проверка товаров в заказе
            {
                prod += $"{orderProduct.ProductArticleNumber}, ";//Добавление товара в строку
                sumDisc += orderProduct.Product.ProductDiscountAmount.Value;//Подсчёт суммарной скидки товаров заказа
                if (orderProduct.Product.ProductQuantityInStock <= 3)//Если количество товара на складе меньше или равно 3, то 
                    paintingCardOrange++;//Счётчик увеличивается на 1
            }
            prod = prod.Substring(0, prod.Length - 2);//Строка со списком товаров урезается с конца (убирается пробел и запятая)
            OrderProductLbl.Text = "Состав заказа: " + prod;//Вывод на строку состава заказа
            CreateDeliveryDate.Text = $"Дата оформления: {order.OrderCreationDate} | Дата доставки: {order.OrderDeliveryDate}";//Вывод на строку дату оформления и дату доставки заказа
            PointCodeLbl.Text = $"Пункт выдачи: {order.OrderPickupPoint.OrderPickupPoint1} | Код выдачи: {order.OrderCodeToGet}";//Вывод на строку пункта и кода выдачи заказа
            if (order.ClientFullName != "")
                ClientFullNameLbl.Text = $"ФИО клиента: {order.ClientFullName}";//Вывод на строку ФИО клиента
            else
                ClientFullNameLbl.Text = " ";//Строка остаётся пустой
            if (paintingCardOrange == 0)//Если в заказе нет товаров, чьё количество на складе меньше 3, то
                this.BackColor = Color.LightSeaGreen;//Карточка окрашивается в цвет LightSeaGreen
            else
                this.BackColor = Color.DarkOrange;//Иначе карточка окрашивается в цвет DarkOrange
        }
    }
}
