﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;
using SchweikaApp.Views.PartialView;

namespace SchweikaApp.Views
{
    public partial class EditProductPage : Form
    {
        public Product product { get; set; } = null;
        public EditProductPage()
        {
            InitializeComponent();
        }
        private void EditProductPage_Load(object sender, EventArgs e)
        {
            foreach (ProductCard productCard in ManagerProductPage.selectedProductCard)
            {
                if (product.ProductImage != "")
                    product.ProductImage = product.ProductImage;
                else
                    product.ProductImage = "";
                //product = DbContext.db.Product.First(x => x.ProductArticle.ToString() == agentCard.IDLabel.Text);
                productBindingSource.DataSource = product;
                if (!string.IsNullOrEmpty(product.ProductImage))
                {
                    LogoPicBox.ImageLocation = product.ProductImage;//.Remove(0, 1);
                }
            }
            //productCategoryBindingSource.DataSource = DbContext.db.ProductCategory.ToList();
        }
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SaveButn_Click(object sender, EventArgs e)
        {
            product = (Product)productBindingSource.Current;
            try
            {
                DbContext.db.SaveChanges();
                MessageBox.Show("Данные сохранены");
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void ChangeImageButn_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files(*.BMP; *.JPG; *.GIF; *.PNG)| *.BMP; *.JPG; *.GIF; *.PNG | All files(*.*) | *.* "; //формат загружаемого файла                                                                                                                           
            if (dialog.ShowDialog() == DialogResult.OK) //если в окне была нажата кнопка "ОК"
            {
                try
                {
                    Bitmap image = new Bitmap(dialog.FileName);
                    this.LogoPicBox.Size = image.Size;
                    LogoPicBox.Image = image;
                    LogoPicBox.Invalidate();
                }
                catch
                {
                    DialogResult rezult = MessageBox.Show("Невозможно открыть выбранный файл",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        
    }
}
