﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.Utils;
using SchweikaApp.ModelEF;
using SchweikaApp.Views;

namespace SchweikaApp
{
    public partial class LoginPage : Form
    {
        static public Form prevPage = null;// статическое открытое поле для предыдущей формы
        public LoginPage()
        {
            InitializeComponent();
        }
        void formClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }
        #region Кнопки
        private void EnterBtn_Click(object sender, EventArgs e)
        {
            if (LoginTB.Text == null || PasswordTB.Text == null)
            {
                MessageBox.Show("Нужно задать логин и пароль!");
                return;
            }
            if (DbContext.db.User.Any(x => x.UserLogin == LoginTB.Text && x.UserPassword == PasswordTB.Text))
            {
                User usr = DbContext.db.User.First(u => u.UserLogin == LoginTB.Text);
                switch (usr.UserRole)
                {
                    case 1:
                    case 3:
                        ManagerPage managerPage = new ManagerPage();// создаем форму директора                        
                        prevPage = this;// сохраняем в форме куда возвращаться
                        managerPage.Show();// показываем форму директора
                        this.Hide();// форму подключения скрываем (но не закрываем!)
                        break;
                    case 2:
                        VisitorProductPage prodPage = new VisitorProductPage();// создаем форму директора                        
                        prevPage = this;// сохраняем в форме куда возвращаться
                        prodPage.Show();// показываем форму директора
                        this.Hide();// форму подключения скрываем (но не закрываем!)
                        break;
                }
                LoginTB.Clear();
                PasswordTB.Clear();
            }
            else
            {
                MessageBox.Show("Пользователя с таким логином и паролем нет!");
                LoginTB.Clear();
                PasswordTB.Clear();
            }
        }
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion
    }
}
