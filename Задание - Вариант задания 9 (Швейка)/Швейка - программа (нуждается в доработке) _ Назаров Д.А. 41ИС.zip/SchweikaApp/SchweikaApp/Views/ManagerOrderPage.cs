﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchweikaApp.ModelEF;
using SchweikaApp.Utils;
using SchweikaApp.Views.PartialView;

namespace SchweikaApp.Views
{
    public partial class ManagerOrderPage : Form
    {
        #region Показ данных
        public Form prevPage = ManagerPage.ActiveForm;
        public static List<Order> orders = new List<Order>();
        public static List<OrderCard> selectedOrderCard = new List<OrderCard>();
        public ManagerOrderPage()
        {
            InitializeComponent();
            orders = DbContext.db.Order.ToList();
        }
        private void GenerateOrderCards(List<Order> order)
        {
            foreach (var ordCard in order)
            {
                OrderCard card = new OrderCard();
                card.GenerateOrderCard(ordCard);
                flowLayoutPanel1.Controls.Add(card);
                card.DoubleClick += new System.EventHandler(this.OrderCard_DoubleClick);
            }
        }
        #endregion
        #region Поиск, фильтрация, сортировка и убывание
        private void OrderPage_Load(object sender, EventArgs e)
        {
            FilterComboBox.SelectedIndex = 0;
            FilterComboBox.Text = "Без фильтрации";
            SortComboBox.SelectedIndex = 0;
        }
        private void SortListView()
        {
            var listUpdate = DbContext.db.Order.ToList();
            #region Поиск
            if (SearchTextBox.Text != "Введите для поиска")//&& !string.IsNullOrWhiteSpace(SearchTextBox.Text)
            {
                listUpdate = listUpdate.Where(p => p.OrderID.ToString().Contains(SearchTextBox.Text.ToLower())
                || p.OrderStatus.OrderStatusName.ToLower().Contains(SearchTextBox.Text.ToLower())).ToList();
            }
            #endregion            
            #region Фильтрация
            if (FilterComboBox.SelectedIndex > 0)
            {
                switch (FilterComboBox.Text)
                {
                    case "0-10%":
                        MessageBox.Show("Данная функция временно не доступна.");
                        FilterComboBox.SelectedIndex = 0;
                        FilterComboBox.Text = "Без фильтрации";
                        break;
                    case "11-14%":
                        MessageBox.Show("Данная функция временно не доступна.");
                        FilterComboBox.SelectedIndex = 0;
                        FilterComboBox.Text = "Без фильтрации";
                        break;
                    case "15% и более":
                        MessageBox.Show("Данная функция временно не доступна.");
                        FilterComboBox.SelectedIndex = 0;
                        FilterComboBox.Text = "Без фильтрации";
                        break;
                }
            }
            #endregion            
            #region Сортировка
            if (SortComboBox.Text == "Стоимость")
            {
                if (!DescCheckBox.Checked)
                {
                    MessageBox.Show("Данная функция временно не доступна.");
                    SortComboBox.SelectedIndex = 0;
                    SortComboBox.Text = "Без сортировки";
                    //listUpdate = listUpdate.OrderBy(a => a.ProductCost).ToList();
                }
                else
                {
                    MessageBox.Show("Данная функция временно не доступна.");
                    SortComboBox.SelectedIndex = 0;
                    SortComboBox.Text = "Без сортировки";
                    //listUpdate = listUpdate.OrderByDescending(a => a.ProductCost).ToList();
                }

            }
            #endregion
            flowLayoutPanel1.Controls.Clear();
            GenerateOrderCards(listUpdate);
        }
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void SortComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void FilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        private void DescCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SortListView();
        }
        #endregion
        #region Кнопки (или объекты со св-вом Click)
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            ManagerPage managerPage = new ManagerPage();
            managerPage.Show();
            this.Close();
        }
        private void OrderCard_DoubleClick(object sender, EventArgs e)
        {
            OrderCard card = sender as OrderCard;
            card.BackColor = Color.FromArgb(153, 0, 153);
            selectedOrderCard.Add(card);
            EditOrderPage editAgent = new EditOrderPage();
            DialogResult result = editAgent.ShowDialog();
            if (result == DialogResult.OK)
            {
                SortListView();
            }
            card.BackColor = Color.White;
            SortListView();
        }
        #endregion
    }
}
