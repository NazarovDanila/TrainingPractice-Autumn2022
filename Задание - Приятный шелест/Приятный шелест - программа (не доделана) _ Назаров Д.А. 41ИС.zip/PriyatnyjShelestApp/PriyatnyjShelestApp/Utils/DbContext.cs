﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PriyatnyjShelestApp.ModelEF;

namespace PriyatnyjShelestApp.Utils
{
    class DbContext
    {
        public static Model1 db = new Model1();
    }
}
