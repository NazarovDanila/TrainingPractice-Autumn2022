﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Eyes_Save.Models;

namespace Eyes_Save.Utils
{
    class DbContext
    {
        public static ModelDb db = new ModelDb();
    }
}
